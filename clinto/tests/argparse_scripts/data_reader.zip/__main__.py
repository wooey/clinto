import argparse
import csv
import sys

parser = argparse.ArgumentParser()
parser.add_argument('-n', type=int, help='The number of rows to read.', default=-1)

if __name__ == '__main__':
    args = parser.parse_args()
    with open('./data.csv', 'r') as f:
        reader = csv.reader(f)
        for index, row in enumerate(reader):
            if index == args.n:
                break
            print(row)

