foo = 'bar'
