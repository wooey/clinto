import argparse
import csv
import os
import pkgutil
import sys
from six import StringIO

# We have a relative import done here to ensure that zip packages are available
from assets import foo

parser = argparse.ArgumentParser()
parser.add_argument('-n', type=int, help='The number of rows to read.', default=-1)

if __name__ == '__main__':
    args = parser.parse_args()
    data = StringIO(pkgutil.get_data('assets', 'data.csv').decode('utf-8'))
    reader = csv.reader(data)
    for index, row in enumerate(reader):
        if index == args.n:
            break
        print(row)

